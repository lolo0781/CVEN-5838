//  ================================================================================
//  ||                                                                            ||
//  ||              fd                                                            ||
//  ||              -------------------------------------------                   ||
//  ||              F I N I T E   D I F F E R E N C E                             ||
//  ||                                                                            ||
//  ||              D E M O N S T R A T I O N   C O D E                           ||
//  ||              -------------------------------------------                   ||
//  ||                                                                            ||
//  ||       Developed by: Scott R. Runnels, Ph.D.                                ||
//  ||                     Los Alamos National Laboratory                         ||
//  ||                                                                            ||
//  ||                For: CU-Boulder CVEN 5838-200 and -200B                     ||
//  ||                     (Not for distribution outside of class)                ||
//  ||                                                                            ||
//  ||          Copyright: 2017-2018 Scott Runnels                                ||
//  ||                                                                            ||
//  ================================================================================

#include "fd.h"

//  ==
//  ||
//  ||      C L A S S:   L A P L A C I A N O N G R I D 
//  ||
//  ||      Does the following:
//  ||
//  ||      (1) Forms a linear system Ax=b representing a 2D
//  ||          finite difference approximation to Laplaces
//  ||          equation on a square.
//  ||      (2) Performs Gauss-Seidel iteration on that linear
//  ||          system up to a specified number of iterations
//  ||          or a specified tolerance.
//  ||      (3) Performs restriction and prolongation steps
//  ||          between coarse and fine objects of this same
//  ||          class.
//  ||          
//  ||          
//  ||       Here is what the grid looks like:
//  ||          
//  ||          
//  ||                                                     ny*nx
//  ||       *-------*-------*-------*-------*  ...   -------*
//  ||       |       |       |       |       |               |
//  ||       |       |       |       |       |               |
//  ||       .       .       .       .       .               .
//  ||       .       .       .       .       .               .
//  ||       .       .       .       .       .               .
//  || 2nx+1  
//  ||       *-------*-------*-------*-------*  ...   -------*
//  ||       |       |       |       |       |               |
//  ||       |       |       |       |       |               |
//  ||       |       |       |       |       |               |
//  ||  nx+1 |       |       |       |       |          2nx  |
//  ||       *-------*-------*-------*-------*  ...   -------*
//  ||       |       |       |       |       |               |
//  ||       |       |       |       |       |               |
//  ||       |       |       |       |       |               |
//  ||       |       |       |       |       |               |
//  ||       *-------*-------*-------*-------*  ...   -------*
//  ||      1       2       3       4                       nx  
//  ||    
//  == 

class LaplacianOnGrid
{

public:

  int nx    , ny   , nrows;
  _D_ length, dx;
  VDD A ;    VD  phi ;  VD  b ; VD residual;  VD error;
  VDD ICF;
  string Name;
  int nxf;
  int nyf;
  int nrowsf;

  //  ==
  //  ||
  //  ||  Constructor:  Initialize values
  //  ||
  //  ==

  LaplacianOnGrid(int ncell_x, int ncell_y, string _Name )
  {
    nx     = ncell_x + 1;
    ny     = ncell_y + 1;
    nxf    = 2*ncell_x + 1;
    nyf    = 2*ncell_y + 1;
    nrowsf = nxf*nyf;
    nrows  = nx*ny;
    length = 1.;
    dx     = length / (nx-1);
    Name   = _Name;

    A.resize(nrows+1); rLOOP A[r].resize(nrows+1);
    b.resize(nrows+1);
    phi.resize(nrows+1);
    residual.resize(nrows+1);
    error.resize(nrows+1);
    ICF.resize(nrows+1); rLOOP ICF[r].resize(nrowsf+1);
  }

  //  ==
  //  ||
  //  ||  Form Linear System Ax = b
  //  ||
  //  ==

  void FormLS()
  {
    
    // ---------------------------------------------------
    // Initialize linear system
    // ---------------------------------------------------
    
    rLOOP cLOOP A[r][c] = 0.;
    rLOOP b[r] = 0.;
    rLOOP phi[r] = 0.;
    
    // ---------------------------------------------------
    // Form matrix entries for the interior grid points
    // ---------------------------------------------------

    _D_ dx2 = dx*dx;
    
    iLOOPi 
      jLOOPi
      {
	int p = pid(i,j);
	A[ p ][ p    ] = -4./dx2;
	A[ p ][ p+1  ] =  1./dx2;
	A[ p ][ p-1  ] =  1./dx2;
	A[ p ][ p+nx ] =  1./dx2;
	A[ p ][ p-nx ] =  1./dx2;
      }
      
    // ---------------------------------------------------
    // Apply boundary conditions
    // ---------------------------------------------------
    
    iLOOP
      {
	int p,j;
	p = pid(i, 1);  A[ p ] [ p ] = 1. ;  b[ p ] =  1.;
	p = pid(i,ny);  A[ p ] [ p ] = 1. ;  b[ p ] = -1.;
      }
    jLOOP
      {
	int p,i;
	p = pid(1, j);  A[ p ] [ p ] = 1. ;  b[ p ] =  1.;
	p = pid(nx,j);  A[ p ] [ p ] = 1. ;  b[ p ] = -1.;
      }
  }

  //  ==
  //  ||
  //  ||  Compute the current residual
  //  ||
  //  ==

  void ComputeResidual()
  {

    rLOOP 
      {
	residual[r] = b[r];
	cLOOP residual[r] -= A[r][c]*phi[c];
      }

  }
  //  ==
  //  ||
  //  ||  Correct current guess for solution using current error
  //  ||
  //  ==

  void Correct()
  {
    rLOOP
      {
	phi[r] += error[r];
      }
  }


  //  ==
  //  ||
  //  ||
  //  ||  Restriction step:  Map the incoming  object's fine field to this object's coarse field 
  //  ||
  //  ||
  //  ==


  //  ==
  //  ||
  //  ||
  //  ||  This is for a 2-D grid, but we draw the 1-D analogy here because it is
  //  ||  easier.  Below, "I" is the incoming object and "T" is "this", i.e., this
  //  ||  object.
  //  ||
  //  ||                        1       2       3       4       5       6
  //  ||   This object          T-------T-------T-------T-------T-------T
  //  ||                                ^
  //  ||                                |
  //  ||                               /|\
  //  ||                              / | \
  //  ||                             /  |  \
  //  ||                            /   |   \
  //  ||   Incoming object      I---I---I---I---I---I---I---I---I---I---I
  //  ||                        1   2   3   4   5   6   7   8   9  10  11
  //  ||
  //  ||
  //  ||   In 2D, here are the weightings:
  //  ||
  //  ||
  //  ||      *------------*------------*------------*
  //  ||      |            |            |            |
  //  ||      |            |            |            |
  //  ||      |            |            |            |
  //  ||      |            |            |            |
  //  ||                                             |
  //  ||      I -----------I----------- I------------*
  //  ||       1/16          1/8          1/16       |
  //  ||      |            |            |            |
  //  ||      |            |            |            |
  //  ||      |            |            |            |
  //  ||                                             |
  //  ||      I ---------- T -----------I------------*
  //  ||       1/8          1/4          1/8         |
  //  ||      |            |            |            |
  //  ||      |            |            |            |
  //  ||      |            |            |            |
  //  ||                                             |
  //  ||      I ---------- I ---------- I------------*
  //  ||       1/16          1/8          1/16       
  //  ||
  //  ||
  //  ||    And, on the boundary:
  //  ||
  //  ||
  //  ||      |            |            |            |
  //  ||      |            |            |            |
  //  ||      |            |            |            |
  //  ||                                             |
  //  ||      I ---------- I -----------I------------*
  //  ||       1/12          1/6          1/12       |
  //  ||      |            |            |            |
  //  ||      |            |            |            |
  //  ||      |            |            |            |
  //  ||                                             |
  //  ||      I ---------- T ---------- I------------*
  //  ||       1/6          1/3          1/6
  //  ||
  //  ||
  //  ==

  void Restrict( VD &T_field, LaplacianOnGrid I , VD &I_field )
  {
    _D_ ei = 1./8.;    
    _D_ qu = 1./4.;
    _D_ st = 1./16.; 
    _D_ th = 1./3.;
    _D_ sx = 1./6.;
    _D_ tw = 1./12.;
    int Tp;      // This objections point ID number
    int iC, jC;  // The incoming objects i-j location corresponding
                 // to this object's i-j location, colocated physically.

    rLOOP T_field[r] = 0.;
    // ------------------------------
    // All interior points
    // ------------------------------

    iLOOPi jLOOPi
    {
      Tp = pid(i,j);  iC = 2*i - 1 ;  jC = 2*j - 1 ;

      T_field[Tp]  = qu *  I_field[Here];
      T_field[Tp] += ei * (I_field[East] + I_field[West] + I_field[South] + I_field[North] );
      T_field[Tp] += st * (I_field[ SW ] + I_field[ SE ] + I_field[ NW  ] + I_field[ NE  ] );
    }

    // ------------------------------
    // Boundary points
    // ------------------------------

    iLOOP { int j;
	    j = 1 ; Tp = pid(i,j);  iC = 2*i - 1 ;  jC = 2*j - 1 ;  T_field[Tp] = I_field[Here] ;
	    j = ny; Tp = pid(i,j);  iC = 2*i - 1 ;  jC = 2*j - 1 ;  T_field[Tp] = I_field[Here] ; 
	  }

    jLOOP { int i;
	    i =  1; Tp = pid(i,j);  iC = 2*i - 1 ;  jC = 2*j - 1 ;  T_field[Tp] = I_field[Here] ; 
	    i = nx; Tp = pid(i,j);  iC = 2*i - 1 ;  jC = 2*j - 1 ;  T_field[Tp] = I_field[Here] ; 
	  }
  }



  //  ==
  //  ||
  //  ||
  //  ||  Prolongation step:  Map this object's coarse field to incoming object's fine field 
  //  ||
  //  ||
  //  ==

  //  ==
  //  ||
  //  ||
  //  ||  This is for a 2-D grid, but we draw the 1-D analogy here because it is
  //  ||  easier.  Below, "I" is the incoming object and "T" is "this", i.e., this
  //  ||  object.
  //  ||
  //  ||                        1   2   3   4   5   6   7   8   9  10  11
  //  ||   Incoming object      I---I---I---I---I---I---I---I---I---I---I
  //  ||
  //  ||                            ^   ^   ^
  //  ||                            |   |   |
  //  ||                             \  |  /   Here, T's point 2 contributes
  //  ||                              \ | /    to I's points 2, 3, and 4.
  //  ||                               \|/      
  //  ||
  //  ||   This object          T-------T-------T-------T-------T-------T
  //  ||                        1       2       3       4       5       6
  //  ||
  //  ||
  //  ||   The weightings for T's contributions to the (finer) I points 
  //  ||   are as follows:
  //  ||
  //  ||      *------------*------------*------------*
  //  ||      |            |            |            |
  //  ||      |            |            |            |
  //  ||      |            |            |            |
  //  ||      |            |            |            |
  //  ||                                             |
  //  ||      I -----------I----------- I------------*
  //  ||       1/16          1/8          1/16       |
  //  ||      |            |            |            |
  //  ||      |            |            |            |
  //  ||      |            |            |            |
  //  ||                                             |
  //  ||      I ---------- T -----------I------------*
  //  ||       1/8          1/4          1/8         |
  //  ||      |            |            |            |
  //  ||      |            |            |            |
  //  ||      |            |            |            |
  //  ||                                             |
  //  ||      I ---------- I ---------- I------------*
  //  ||       1/16          1/8          1/16       
  //  ||
  //  ||
  //  ||    And, on the boundary:
  //  ||
  //  ||
  //  ||      |            |            |            |
  //  ||      |            |            |            |
  //  ||      |            |            |            |
  //  ||                                             |
  //  ||      I ---------- I -----------I------------*
  //  ||       1/12          1/6          1/12       |
  //  ||      |            |            |            |
  //  ||      |            |            |            |
  //  ||      |            |            |            |
  //  ||                                             |
  //  ||      I ---------- T ---------- I------------*
  //  ||       1/6          1/3          1/6
  //  ||
  //  ||
  //  ==

  void Prolong( VD &T_field, LaplacianOnGrid I , VD &I_field )
  {
    _D_ ei = 1./8.;    
    _D_ qu = 1./4.;
    _D_ st = 1./16.; 
    _D_ th = 1./3.;
    _D_ sx = 1./6.;
    _D_ tw = 1./12.;
    _D_ Tf;      // T_field, evaluated at this object's point ID number
    int iC, jC;  // The incoming objects i-j location corresponding
                 // to this object's i-j location, colocated physically.

    // ------------------------------
    // Initialize I_field
    // ------------------------------

    for ( int p = 1 ; p <= I.nrows ; ++p ) I_field[p] = 0.;

    // ------------------------------
    // Scale weights
    // ------------------------------

    ei *= 4.;
    qu *= 4.;
    st *= 4.;
    th *= 3.;
    sx *= 3.;
    tw *= 3.;

    // ------------------------------
    // All interior points
    // ------------------------------

    iLOOPi jLOOPi
    {
      Tf = T_field[pid(i,j)];  iC = 2*i - 1 ;  jC = 2*j - 1 ;

      I_field[  Here  ] += qu * Tf;
      I_field[  West  ] += ei * Tf;
      I_field[  East  ] += ei * Tf;
      I_field[  South ] += ei * Tf;
      I_field[  North ] += ei * Tf;
      I_field[  SW    ] += st * Tf;
      I_field[  SE    ] += st * Tf;
      I_field[  NE    ] += st * Tf;
      I_field[  NW    ] += st * Tf;
    }

    // ------------------------------
    // Boundary points
    // ------------------------------


    iLOOP { int j;
	    j = 1;
	    Tf = T_field[pid(i,j)];  iC = 2*i - 1 ;  jC = 2*j - 1 ;

            I_field[ Here    ] += th * Tf;
            I_field[ West    ] += sx * Tf;
            I_field[ East    ] += sx * Tf;
            I_field[ North   ] += sx * Tf;
            I_field[ NW      ] += tw * Tf;
            I_field[ NE      ] += tw * Tf;

	    j = ny;
	    Tf = T_field[pid(i,j)];  iC = 2*i - 1 ;  jC = 2*j - 1 ;
            I_field[ Here  ] += th *  Tf;
            I_field[ West  ] += sx *  Tf;
            I_field[ East  ] += sx *  Tf;
            I_field[ South ] += sx *  Tf;
            I_field[ SW    ] += tw *  Tf;
            I_field[ SE    ] += tw *  Tf;
	  }

    jLOOP { int i;
	    i = 1;
	    Tf = T_field[pid(i,j)];  iC = 2*i - 1 ;  jC = 2*j - 1 ;
            I_field[ Here  ]  += th * Tf;
            I_field[ South ]  += sx * Tf;
            I_field[ North ]  += sx * Tf;
            I_field[ East  ]  += sx * Tf;
            I_field[ SE    ]  += tw * Tf;
            I_field[ NE    ]  += tw * Tf;

	    i = nx;
	    Tf = T_field[pid(i,j)];  iC = 2*i - 1 ;  jC = 2*j - 1 ;
            I_field[ Here  ]  += th * Tf;
            I_field[ South ]  += sx * Tf;
            I_field[ North ]  += sx * Tf;
            I_field[ East  ]  += sx * Tf;
            I_field[ SE    ]  += tw * Tf;
            I_field[ NE    ]  += tw * Tf;
	  }
  }



  //  ==
  //  ||
  //  ||  Utility routines
  //  ||
  //  ==

  int pid(int i,int j) { return i + (j-1)*nx; }  // Given i-j, return point ID.
  void reset_phi() { cout << "Reset phi in " << Name << endl; rLOOP phi[r] = 0.; }
  #include "plotter.h"
  #include "gauss_seidel.h"

};



//  ==
//  ||
//  ||
//  ||  Main Program
//  ||
//  ||
//  ==

int main()
{

  cout << "\n";
  cout << "---------------------------------------------\n";
  cout << "|                                           |\n";
  cout << "| F I N I T E   D I F F D E R E N C E       |\n";
  cout << "| D E M O   C O D E                         |\n";
  cout << "|                                           |\n";
  cout << "---------------------------------------------\n";
  cout << "\n";

  LaplacianOnGrid C( 5, 5, "C" );
  LaplacianOnGrid F(10,10, "F" );

  F.FormLS();
  C.FormLS();
  cout << "                                          \n";
  cout << "Standard Gauss-Seidel on fine system:\n";
  cout << "------------------------------------------\n";
  cout << "                                          \n";

  F.GaussSeidel(200, F.b , F.phi );
  F.reset_phi();

  cout << "                                          \n";
  cout << "One Coarse-Grid Correction:\n";
  cout << "------------------------------------------\n";
  cout << "                                          \n";
                                                 // Fine Grid Residual
                                                 // ----------------------------
  F.GaussSeidel(2, F.b, F.phi );                 // Iteration
  F.ComputeResidual();                           // Compute residual
  F.plot("r",F.residual);                        // Plot residual
  C.Restrict(C.residual, F, F.residual);         // Fine --> Coarse (residual)

                                                 // Coarse Grid Error
                                                 // ----------------------------
  C.plot("r",C.residual);                        // Plot residual
  C.GaussSeidel(10, C.residual, C.error);        // Compute error
  C.plot("e",C.error);                           // Plot error
  C.Prolong(C.error, F, F.error);                // Coarse --> Fine (error)

                                                 // Fine Grid Solution
                                                 // ----------------------------
  F.plot("e",F.error);                           // Plot error
  F.Correct();                                   // Correct solution using error
  F.plot("phi_c",F.phi);                         // Plot corrected solution
  F.GaussSeidel(200, F.b, F.phi);                // Iterate on solution
  F.plot("phi_f",F.phi);                         // Plot solution


  F.reset_phi();

  cout << "                                          \n";
  cout << "Plot Results:\n";
  cout << "------------------------------------------\n";
  cout << "                                          \n";

  F.plot("phi",F.phi);      

}
