//  ================================================================================
//  ||                                                                            ||
//  ||              fd                                                            ||
//  ||              -------------------------------------------                   ||
//  ||              F I N I T E   D I F F E R E N C E                             ||
//  ||                                                                            ||
//  ||              D E M O N S T R A T I O N   C O D E                           ||
//  ||              -------------------------------------------                   ||
//  ||                                                                            ||
//  ||       Developed by: Scott R. Runnels, Ph.D.                                ||
//  ||                     Los Alamos National Laboratory                         ||
//  ||                                                                            ||
//  ||                For: CU-Boulder CVEN 5838-200 and -200B                     ||
//  ||                     (Not for distribution outside of class)                ||
//  ||                                                                            ||
//  ||          Copyright: 2017-2018 Scott Runnels                                ||
//  ||                                                                            ||
//  ================================================================================

#include "fd.h"
#include "UserInput.h"

//  ==
//  ||
//  ||      C L A S S:   L A P L A C I A N O N G R I D 
//  ||
//  ||      Does the following:
//  ||
//  ||      (1) Forms a linear system Ax=b representing a 2D
//  ||          finite difference approximation to Laplaces
//  ||          equation on a square.
//  ||      (2) Performs Gauss-Seidel iteration on that linear
//  ||          system up to a specified number of iterations
//  ||          or a specified tolerance.
//  ||          
//  ||       Here is what the grid looks like:
//  ||          
//  ||          
//  ||                                                     ny*nx
//  ||       *-------*-------*-------*-------*  ...   -------*
//  ||       |       |       |       |       |               |
//  ||       |       |       |       |       |               |
//  ||       .       .       .       .       .               .
//  ||       .       .       .       .       .               .
//  ||       .       .       .       .       .               .
//  || 2nx+1  
//  ||       *-------*-------*-------*-------*  ...   -------*
//  ||       |       |       |       |       |               |
//  ||       |       |       |       |       |               |
//  ||       |       |       |       |       |               |
//  ||  nx+1 |       |       |       |       |          2nx  |
//  ||       *-------*-------*-------*-------*  ...   -------*
//  ||       |       |       |       |       |               |
//  ||       |       |       |       |       |               |
//  ||       |       |       |       |       |               |
//  ||       |       |       |       |       |               |
//  ||       *-------*-------*-------*-------*  ...   -------*
//  ||      1       2       3       4                       nx  
//  ||    
//  == 

class LaplacianOnGrid
{

public:

  int nx    , ny   , nrows;
  _D_ length, dx;
  VDD A ;    VD  phi ;  VD  b ;  VD phi_anl;
  string mmsName;

  _D_ k0, k1, k2;

  //  ==
  //  ||
  //  ||  Constructor:  Initialize values
  //  ||
  //  ==

  LaplacianOnGrid( UserInput &UI )
  {

    // Transfer UserInput object data to local storage

    nx      = UI.ncell + 1;
    ny      = UI.ncell + 1;
    nrows   = nx*ny;
    length  = UI.length;
    dx      = length / (nx-1);
    mmsName = UI.mmsName;
    k0      = UI.k0;
    k1      = UI.k1;
    k2      = UI.k2;

    // Allocate memory

    A.resize(nrows+1); rLOOP A[r].resize(nrows+1);
    b.resize(nrows+1);
    phi.resize(nrows+1);
    phi_anl.resize(nrows+1);
    rLOOP phi[r] = 0.;
  }

  //  ==
  //  ||
  //  ||  Evaluate nonlinear conductivity
  //  ||
  //  ==

  _D_ Eval_k( int p    )  {  return ( k0 + k1*phi[p] + k2*phi[p]*phi[p] );   }
  _D_ Eval_k( _D_ soln )  {  return ( k0 + k1*soln   + k2*soln  *soln   );   }

  //  ==
  //  ||
  //  ||  Form Linear System Ax = b
  //  ||
  //  ==

  void FormLS()
  {
    
    // ---------------------------------------------------
    // Initialize linear system
    // ---------------------------------------------------
    
    rLOOP cLOOP A[r][c] = 0.;
    rLOOP b[r] = 0.;
    
    // ---------------------------------------------------
    // Form matrix entries for the interior grid points
    // ---------------------------------------------------

    _D_ dx2 = dx*dx;
    
    iLOOPi 
      jLOOPi
      {
	int p = pid(i,j);
	A[ p ][ p    ] = -Eval_k(p) * 4./dx2;   
	A[ p ][ p+1  ] =  Eval_k(p) * 1./dx2;
	A[ p ][ p-1  ] =  Eval_k(p) * 1./dx2;
	A[ p ][ p+nx ] =  Eval_k(p) * 1./dx2;
	A[ p ][ p-nx ] =  Eval_k(p) * 1./dx2;
      }
      
    // ---------------------------------------------------
    // Apply boundary conditions
    // ---------------------------------------------------
    
    iLOOP
      {
	int p,j;
	p = pid(i, 1);  A[ p ] [ p ] = 1. ;  b[ p ] =  1.;
	p = pid(i,ny);  A[ p ] [ p ] = 1. ;  b[ p ] = -1.;
      }
    jLOOP
      {
	int p,i;
	p = pid(1, j);  A[ p ] [ p ] = 1. ;  b[ p ] =  1.;
	p = pid(nx,j);  A[ p ] [ p ] = 1. ;  b[ p ] = -1.;
      }

    // ---------------------------------------------------
    // Modify Linear System for manufactured solutions
    // ---------------------------------------------------

    if ( mmsName != "none") 
      {
	// Modify RHS for interior nodes

	iLOOPi jLOOPi  { b[ pid(i,j)  ] = k_L_MMS( (i-1)*dx   , (j-1)*dx );  }

	// Apply BCs using MMS

	iLOOP b[ pid(i, 1) ] = f_MMS( (i-1)*dx , 0.        );
	iLOOP b[ pid(i,ny) ] = f_MMS( (i-1)*dx , length    );
	jLOOP b[ pid(1, j) ] = f_MMS( 0.       , (j-1)*dx  );
	jLOOP b[ pid(nx,j) ] = f_MMS( length   , (j-1)*dx  );

      }

    // ---------------------------------------------------
    // Store manufactured solution for plotting and error
    // ---------------------------------------------------

    if ( mmsName != "none") 
      {
	iLOOP jLOOP  phi_anl[ pid(i,j) ] =f_MMS( (i-1)*dx , (j-1)*dx );
	plot("phi_anl",phi_anl);                       
      }

  }


  //  ==
  //  ||
  //  ||  Manufactured Solutions: Management routines that return function values 
  //  ||                          for BCs and Laplacian values for RHS.
  //  ||
  //  ==

  _D_ f_MMS( _D_ x , _D_ y) // Returns function value of selected solution
  {
    if ( mmsName == "linear" ) return f_Linear_xy(x,y);
    if ( mmsName == "quad"   ) return f_Quad_xy(x,y);
    if ( mmsName == "cubic"  ) return f_Cubic_xy(x,y);
    if ( mmsName == "sine"   ) return f_sine_xy(x,y);
  }
  _D_ L_MMS( _D_ x , _D_ y) // Returns laplacian of selected solution
  {
    if ( mmsName == "linear" ) return L_Linear_xy(x,y)  ;
    if ( mmsName == "quad"   ) return L_Quad_xy(x,y)    ;
    if ( mmsName == "cubic"  ) return L_Cubic_xy(x,y)   ;  
    if ( mmsName == "sine"   ) return L_sine_xy(x,y)    ;
  }
  _D_ k_L_MMS( _D_ x , _D_ y) // Returns laplacian of selected solution * k
  {
    if ( mmsName == "linear" ) return L_MMS(x,y) * Eval_k( f_Linear_xy(x,y) ) ;
    if ( mmsName == "quad"   ) return L_MMS(x,y) * Eval_k( f_Quad_xy  (x,y) ) ;
    if ( mmsName == "cubic"  ) return L_MMS(x,y) * Eval_k( f_Cubic_xy (x,y) ) ;  
    if ( mmsName == "sine"   ) return L_MMS(x,y) * Eval_k( f_sine_xy  (x,y) ) ;
  }

  //  ==
  //  ||
  //  ||  Manufactured Solutions: Function and Laplacian values
  //  ||
  //  ==

  _D_ f_Linear_xy (_D_ x, _D_ y)  {  return (x + y);          }   
  _D_ f_Quad_xy   (_D_ x, _D_ y)  {  return (x*x + y*y);      }   
  _D_ f_Cubic_xy  (_D_ x, _D_ y)  {  return (x*x*x + y*y*y);  }   
  _D_ f_sine_xy   (_D_ x, _D_ y)  {  return ( sin(5.*(x+y))); }   

  _D_ L_Linear_xy (_D_ x, _D_ y)  {  return (  0.                );   }   
  _D_ L_Quad_xy   (_D_ x, _D_ y)  {  return (  4.                );   }   
  _D_ L_Cubic_xy  (_D_ x, _D_ y)  {  return (  6.*x + 6.*y       );   }   
  _D_ L_sine_xy   (_D_ x, _D_ y)  {  return ( -50.*sin(5.*(x+y)) );   }   

  // ==
  // ||
  // || Error Norms (1): RMS
  // ||
  // ==

  _D_ RMS_error()
  {
    _D_ sum = 0.;
    int nval = 0;

    iLOOPi jLOOPi
    {
      _D_ e = phi[ pid(i,j) ] - f_MMS( (i-1)*dx , (j-1)*dx );
      sum += e*e;
      ++nval;
    }
    return sqrt(sum)/nval;
  }

  // ==
  // ||
  // || Error Norms (2):  L2 error as an integral
  // ||
  // ==

  _D_ L2_error()
  {
    _D_ dA       = (dx/10.) * (dx/10.);
    _D_ area     = 0.;
    _D_ integral = 0.;

    iLOOPi jLOOPi
    {
      for ( int K = 1 ; K <= 10 ; ++ K )
	for ( int L = 1 ; L <= 10 ; ++ L )
	  {
	    _D_ e   = phi[ pid(i,j) ] - f_MMS( (i-1)*dx , (j-1)*dx );
	    integral += e*e * dA;
	    area     +=  1. * dA;
	  }
    }
    return integral/area;
  }


  // ==
  // ||
  // || Error Norms (3): Max error 
  // ||
  // ==

  _D_ max_error()
  {
    _D_ error = 0.;

    iLOOPi jLOOPi
    {
      _D_ e   = phi[ pid(i,j) ] - f_MMS( (i-1)*dx , (j-1)*dx );
      e = fabs(e);
      if ( e > error ) error = e;
    }
    return error;
  }

  //  ==
  //  ||
  //  ||  Utility routines
  //  ||
  //  ==

  int pid(int i,int j) { return i + (j-1)*nx; }  // Given i-j, return point ID.

  #include "plotter.h"
  #include "gauss_seidel.h"

};



//  ==
//  ||
//  ||
//  ||  Main Program
//  ||
//  ||
//  ==

int main()
{

  cout << "\n";
  cout << "---------------------------------------------\n";
  cout << "|                                           |\n";
  cout << "| F I N I T E   D I F F E R E N C E         |\n";
  cout << "| D E M O   C O D E                         |\n";
  cout << "|                                           |\n";
  cout << "---------------------------------------------\n";
  cout << "\n";

  cout << "                                          \n";
  cout << "User Inputs:                              \n";
  cout << "------------------------------------------\n";
  cout << "                                          \n";

  UserInput UI;

  UI.ReadInput();
  UI.EchoInput();

  LaplacianOnGrid F( UI );

  cout << "                                          \n";
  cout << "Solve Non-Linear System:\n";
  cout << "------------------------------------------\n";
  cout << "                                          \n";


  for ( int iter = 1 ; iter <= UI.max_SA_iter ; ++iter )
    {
      F.FormLS();
      F.GaussSeidel(1000, F.b , F.phi );
    }

  F.plot("phi",F.phi);      

  if ( F.mmsName != "none")
    {
      cout << "                                          \n";
      cout << "Compute Error:\n";
      cout << "------------------------------------------\n";
      cout << "                                          \n";

      cout << "ERROR: " << F.nx << " " << F.RMS_error() << " " << F.L2_error() << " " << F.max_error() << endl;
    }

  cout << "                                          \n";
  cout << "------------------------------------------\n";
  cout << "Normal Termination  \n";
  cout << "------------------------------------------\n";
  cout << "                                          \n";
}
