#! /usr/bin/env python

import os
import sys

if __name__=='__main__':
    DEMO = os.environ['DEMO']

    os.system(DEMO + '/fd_TestingPackage/strict_comparator.py -s phi.plt_std -n phi.plt')


