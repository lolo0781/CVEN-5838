//  ==
//  ||
//  ||      C L A S S:   U S E R I N P U T
//  ||
//  ||      Reads, echos, and contains the input from the "input" file
//  ||
//  ||
//  ==

class UserInput
{
public:

  // -----------------------------------------------------------------------------------------
  // Here are all of the inputs that the user can set
  // -----------------------------------------------------------------------------------------

  _D_    length      ;   // Size of domain in the x- and y-directions
  _I_    ncell       ;   // Number of cells in the x- and y-directions
  _D_    k0, k1, k2  ;   // Conductivity parameters for k(T) = k0 + k1*phi + k2*phi^2 
  _I_    max_SA_iter ;   // Max SA iterations
  _I_    max_GS_iter ;   // Max GS iterations
  _D_    gs_tol      ;   // Gauss-Seidel tolerance
  string mmsName     ;   // Name of the solution used in the method of manufactured solutions
                         //
                         // Test Harness:
                         //
  _I_ n_fnc          ;   // Number of subroutines/functions to be tested in this execution
  VS  fnc            ;   // Array of subroutine/function names to be tested in this execution
  VTD TD             ;   // An array of TestData objects

  // -
  // |
  // | Here the values are initialized when the object is put into memory
  // |
  // -

  UserInput()
  {
    length      =  1.    ; 
    ncell       = 10     ;  
    k0          =  1.    ;
    k1          =  0.    ;
    k2          =  0.    ;
    max_SA_iter = 10     ; 
    max_GS_iter = 1000   ; 
    gs_tol      = 1.e-10 ;
    mmsName     = "none" ;
    n_fnc       = 0      ;
  }


  // -
  // |
  // | This routine reads the user input from the file named "input"
  // |
  // -

  void ReadInput()
  {

    // Opens a file named "input" and looks for commands, each starting with a "$" sign.
    // If those commands match any of the commands below, read the associated input value.

    string line;  ifstream input("input");
    while ( getline(input,line) )
      {
	if ( line == "$mesh"            ) { input >> length;      input >> ncell     ;                         } 
	if ( line == "$material_k"      ) { input >> k0;          input >> k1        ; input >> k2;            }
	if ( line == "$SA"              ) { input >> max_SA_iter;                                              }
	if ( line == "$GS"              ) { input >> max_GS_iter;                                              }
	if ( line == "$GS_tol"          ) { input >> gs_tol;                                                   }
	if ( line == "$MMS"             ) { input >> mmsName;                                                  }
	if ( line == "$TestHarness"     ) { input >> n_fnc;                                                    }
      }
    // Read Test Harness Input

    TD.resize(n_fnc+1);            // One test data object for each function to be tested
    input.clear();                 // Reset input file
    input.seekg(0);

    int fnc_count = 0;             // Search for and read testing input
    while ( getline(input,line) )
      {
	if ( line == "$TestData" )
	  {
	    ++fnc_count;
	    TD[fnc_count].ReadData(input);
	  }
      }

    input.close();
  }


  void EchoInput()
  {
    cout << "(o) Domain length              : " << length          << endl;
    cout << "(o) No. cells in x/y direction : " << ncell           << endl;
    cout << "(o) Conductivity param k0      : " << k0              << endl;
    cout << "(o)                    k1      : " << k1              << endl;
    cout << "(o)                    k2      : " << k2              << endl;
    cout << "(o) Max. SA iterations         : " << max_SA_iter     << endl;
    cout << "(o) Max. GS iterations         : " << max_GS_iter     << endl;
    cout << "(o) Gauss-Seidel tolerance     : " << gs_tol          << endl;
    cout << "(o) MMS solution name          : " << mmsName         << endl;
    if ( n_fnc > 0 )
      {
	cout << " " << endl;
	cout << "====================================== \n";
	cout << "This run is executing the test harness \n";
	cout << "====================================== \n";
	cout << " " << endl;
	cout << "(o) Functions involved in unit testing: " << endl;
	RLOOP cout << "      (*)  " << TD[r].Name          << endl;
  }
  }


  // -
  // |
  // | This function returns a value of true if no unit testing of the code is being performed, i.e.,
  // | if n_fnc = 0.  If unit testing *is* being performed, this routine returns true if the routine
  // | name provided in the argument list is also included in the list of routines (provided by the 
  // | user) to be tested.
  // |
  // -

  bool ExecuteMe(string fnc_name)
  {
    if ( n_fnc == 0 ) return false;                   // No unit testing being performed.  Execute normally.
    RLOOP if ( fnc_name == TD[r].Name ) return true;  // Function "fnc_name" is to be unit tested.  Execute using special data.
    return false;                                     // Do not execute this routine.
  }

  // -
  // |
  // | This function returns a pointer to a TestData object for the subroutine provided in the 
  // | argument list.
  // |
  // -

  TestData *GetTD(string fnc_name)
  {
    RLOOP if ( fnc_name == TD[r].Name )	return &TD[r];

    cout << "Pointer to tested function not found.  Exiting.\n";
    exit(-1);
  }

};

