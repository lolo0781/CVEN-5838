
//  ==
//  ||
//  ||      C L A S S:   E R R O R E N T R Y
//  ||
//  ||      This is a class that represents an error in the code.  Objects of this
//  ||      class may be strung together in a linked list where the first object is 
//  ||      the initial error and subsequent objects represent higher levels in the
//  ||      code.
//  || 
//  ==

class ErrorEntry
{
public:
  int          TypeID;
  int          IDnumber;
  string       Description;
  string       PossibleCause;
  string       RecommendedAction;
  ErrorEntry  *Next;
  std::fstream error_log;
  string       error_log_filename;

  int numErrors;
  VS M;    // Message
  VI I;    // Message index number
  VS F;    // Function in which error occurred
  VS C;    // Cause
  VS A;    // Recommended action

  // -
  // |
  // | Constructors
  // |
  // -

  ErrorEntry(){}

  // -
  // |
  // | Constructor: This constructor sets up the database of error messages and a 
  // |              link to a preceding error message, i.e., this is the constructor
  // |              that enables a linked-list of error objects.
  // |             
  // -

  ErrorEntry(ErrorEntry *E, int _MY_ID)
  {

    // ---------------------------
    // Database of error messages
    // ---------------------------

    string NL = "\n                    ";

    numErrors = 6;

    M.resize(numErrors+1);
    I.resize(numErrors+1);
    F.resize(numErrors+1);
    C.resize(numErrors+1);
    A.resize(numErrors+1);
    
    M[1] = "Bad value for number of functions" ; 
    I[1] = 1001 ; 
    F[1] = "ReadData" ; 
    C[1] = "User input error" ; 
    A[1] = "Examine input file";
    
    M[2]  = "Negative thermal conductivity"     ; 
    I[2]  = 1002 ; 
    F[2]  = "K"        ; 
    C[2]  =      "It may be that the coefficients for the quadratic form of";
    C[2] += NL + "K=K(T) are incorrect, causing a negative K(T) value for";
    C[2] += NL + "otherwise reasonable temperatures.  Antoher possible cause is";
    C[2] += NL + "that the nonlinear solver is causing excursions of temperature";
    C[2] += NL + "that lead to a negative K(T).";
    A[2]  =      "For the first possible cause, check your inputs.  For the second,";
    A[2] += NL + "consider increasing the relaxation parameter used in nonlinear iterations.";

    M[3] = "Problem forming linear system"     ; 
    I[3] = 1003 ; 
    F[3] = "FormLS"   ; 
    C[3] = "Error encountered evaluating material model" ; 
    A[3] = "Check inputs. See other messages.";
    
    M[4] = "Gauss-Seidel iterations did not converge.";
    I[4] = 1004 ; 
    F[4] = "GaussSeidel"   ; 
    C[4] = "Nonlinear system may be leading to poorly conditioned matrix.";
    A[4] = "Try a smaller problem and turn on matrix checking.";

    M[5] = "The nonlinear solver encountered an error forming the linear system.";
    I[5] = 1005 ; 
    F[5] = "NonlinearSolver";
    C[5] = "In forming the linearized system during an iteration, an error was encountered.";
    A[5] = "Check finer-scale error messsage.";

    M[6] =          "NonlinearSolver: The nonlinear solver encountered an error when";
    M[6] += NL + "trying to solve the linearized system.";
    I[6] = 1006 ; 
    F[6] = "NonlinearSolver";
    C[6] = "The nonlinear solver may be producing a bad matrix.";
    A[6] = "Turn on the option of printing solution iterates to see if the solver is diverging.";

    // ---------------------------
    // Set error filename
    // ---------------------------

    error_log_filename = "ErrorLog";

    // ---------------------------------------------
    // Store the error ID for this particular error
    // ---------------------------------------------

    IDnumber = _MY_ID;

    // ---------------------------------------------
    // Link to the preceeding error, if there is one
    // ---------------------------------------------

    Next = E;
  }


  // -
  // |
  // | AppendMessage: This routine takes this object's error message and appends it to 
  // |                the incoming message.  It then asks the next object in the 
  // |                linked list to append its message.
  // -

  void AppendMessage(string &Message)
  {

    // Convert the error ID number into a string for printing

    ostringstream convert; convert << I[IDnumber];
    string _s_IDnumber = convert.str();

    // Append this object's incoming error message to the incoming message

    Message +=  "ErrorID           : " + _s_IDnumber  +  "\n";
    Message +=  "Description       : " + M[IDnumber]  +  "\n";
    Message +=  "Possible Cause    : " + C[IDnumber]  +  "\n";
    Message +=  "Recommended Action: " + A[IDnumber]  +  "\n";
    Message +=                                           "\n";

    // If there is another ErrorEntry object in this linked list of objects,
    // ask it to append its message also.

    if ( Next ) Next->AppendMessage(Message);
  }

  // -
  // |
  // | Fatal:  Print the error messages to the screen and to the ErrorLog file.
  // |         Then cease execution.
  // |
  // -

  void FatalError(int header)
  {
    string Header = "";
    Header += "\n";
    Header += "\n";
    Header += "---------------------------------------------\n";
    Header += "|                                           |\n";
    Header += "| A fatal error has occurred                |\n";
    Header += "|                                           |\n";
    Header += "| Below, error messages from the software   |\n";
    Header += "| are provided, in the order of highest     |\n";
    Header += "| level routine down to the lowest level    |\n";
    Header += "| routine that originally generated the     |\n";
    Header += "| error.                                    |\n";
    Header += "|                                           |\n";
    Header += "---------------------------------------------\n";
    Header += "\n";

    if ( header )
      {
	error_log.open(error_log_filename.c_str(),std::ios::out);
	cout      << Header;
	error_log << Header;
      }

    // (1.2) The error message

    ostringstream convert; convert << IDnumber;
    string _s_IDnumber = convert.str();

    string Message = "";

    AppendMessage(Message);

    cout      << Message;
    error_log << Message;

    // (1.3) The footer

    string Footer = "";

    Footer += "\n";
    Footer += "---------------------------------------------\n";
    Footer += "|   Execution Ending                        |\n";
    Footer += "---------------------------------------------\n";
    Footer += "\n";
    Footer += "\n";

    cout      << Footer;
    error_log << Footer;

    error_log.close();

    exit(0);
  }

};
