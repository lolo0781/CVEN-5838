
//  ==
//  ||
//  ||      C L A S S:   T E S T D A T A
//  ||
//  ||      This is a class that contains a double-precision and integer arrays
//  ||      of values read from the input file that will be used to test an individual
//  ||      function in this code.  The name of the function tested is stored in the
//  ||      "Name" variable in this class.  
//  ||
//  ||      This class not only houses the data but also reads the data from the input
//  ||      file.
//  || 
//  ==

class TestData
{
public:
  _I_ nD  ; VD Ddata;   // Number and array of double-precision values
  _I_ nI  ; VD Idata;   // Number and array of integer values
  string Name;          // Name of the function for which this data is intended

  void ReadData(ifstream &input_file)
  {
    input_file >> Name;                      // Read the function name for which this test data is intended
    input_file >> nD;  Ddata.resize(nD+1);   // Read the number of real values provided, and resize the array accordingly
    input_file >> nI;  Idata.resize(nI+1);   // Repeat for the integer values

    for ( int i = 1; i <= nD ; ++i ) input_file >> Ddata[i];   // Read the user's real numbers from the file
    for ( int i = 1; i <= nI ; ++i ) input_file >> Idata[i];   // Repeat for the integer values
      
  }
};

