  //  ==
  //  ||
  //  ||  Test Harness for void K()
  //  ||
  //  ||  This test harness uses the user-supplied data to plot K = K(T).
  //  ||
  //  ==

void TestHarness_Eval_k( UserInput &UI )
  {
    
    // Get pointer to the user-supplied test data
    
    TestData *MyTD = UI.GetTD("Eval_k");  

    // Create local arrays for x-y plotting
    
    VD K_of_T;
    VD Tval  ;
    int num  = MyTD->nD;

    K_of_T.resize(num+1);

    // Create a fictitious phi array for testing

    VD my_phi;
    my_phi.resize(num+1);

    // Populate the solution array with the user-supplied temperature data
    
    for ( int i = 1 ; i <= num ; ++i ) my_phi[i] = MyTD->Ddata[i];
       
    // Populate the K values 

    for ( int i = 1 ; i <= num ; ++i )  K_of_T[i] = Eval_k( i , my_phi , UI , true);
    
    // Plot the results
					   
    plot("k_of_T", my_phi , K_of_T);  

  }
