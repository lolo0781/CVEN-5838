#! /usr/bin/env python

import os
import sys

if __name__=='__main__':
    DEMO = os.environ['DEMO']

    os.system(DEMO + '/fd_TestingPackage/strict_comparator.py -s ErrorLog_std -n ErrorLog')


