#! /usr/bin/env python

import os
import sys

if __name__=='__main__':
    os.system('rm -f *.plt')
    os.system('rm -f *.png')
    os.system('rm -f TestResult_summary')


