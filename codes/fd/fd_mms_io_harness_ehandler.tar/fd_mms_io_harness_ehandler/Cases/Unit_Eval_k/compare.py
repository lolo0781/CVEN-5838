#! /usr/bin/env python

import os
import sys

if __name__=='__main__':
    DEMO = os.environ['DEMO']

    os.system(DEMO + '/fd_TestingPackage/strict_comparator.py -s k_of_T.plt_std -n k_of_T.plt')


